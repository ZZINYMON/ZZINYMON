package com.ohgiraffers.lsj;

public class Application {

    public static void main(String[] args) {

    }
}
